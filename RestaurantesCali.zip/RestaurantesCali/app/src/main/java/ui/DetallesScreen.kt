package com.example.restaurantescali.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.restaurantescali.viewmodel.Restaurante
import com.example.restaurantescali.R

@Composable
fun DetallesScreen(
    backgroundColor: MutableState<Color>,
    textColor: Color,
    surfaceColor: Color,
    onRestauranteClick: (Restaurante) -> Unit,
    historial: List<Restaurante>
) {
    val restaurantes = remember {
        listOf(
            Restaurante("Storia D’Amore", "Restaurante italiano elegante con platos clásicos.", "Calle 4 #10-30, Cali", R.drawable.storia, 4.8f, 135),
            Restaurante("El Zaguán de San Antonio", "Comida típica colombiana en una casa colonial.", "Carrera 6 #3-03, Cali", R.drawable.zaguan, 4.5f, 98),
            Restaurante("Ringlete", "Sabores tradicionales del Valle con toque gourmet.", "Avenida 6N #23DN-40, Cali", R.drawable.ringlete, 4.9f, 200)
        )
    }

    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    var filtro by remember { mutableStateOf("explorar") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor.value)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar restaurantes", color = textColor) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mayor Valoración", "Menor Valoración", "Explorar").forEach { label ->
                AssistChip(
                    onClick = { filtro = label.lowercase() },
                    label = { Text(label, color = textColor) },
                    shape = RoundedCornerShape(50),
                    colors = AssistChipDefaults.assistChipColors(containerColor = surfaceColor)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val resultados = when (filtro) {
            "mayor valoración" -> restaurantes.sortedByDescending { it.valoracion }
            "menor valoración" -> restaurantes.sortedBy { it.valoracion }
            else -> restaurantes.filter {
                it.nombre.contains(searchQuery.text, ignoreCase = true)
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(resultados) { restaurante ->
                RestauranteCard(restaurante = restaurante, onClick = { onRestauranteClick(restaurante) }, textColor = textColor, surfaceColor = surfaceColor)
            }
        }
    }
}

@Composable
fun RestauranteCard(restaurante: Restaurante, onClick: () -> Unit, textColor: Color, surfaceColor: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = surfaceColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            Image(
                painter = painterResource(restaurante.imagenRes),
                contentDescription = restaurante.nombre,
                modifier = Modifier
                    .size(80.dp)
                    .aspectRatio(1f)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = restaurante.nombre,
                    style = MaterialTheme.typography.titleMedium,
                    color = textColor
                )
                Text(
                    text = restaurante.descripcion,
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor.copy(alpha = 0.7f)
                )
            }
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = "Valoración",
                tint = Color(0xFFFFC107),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
