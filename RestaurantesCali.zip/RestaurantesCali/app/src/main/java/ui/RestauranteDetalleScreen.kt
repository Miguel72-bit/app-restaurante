package com.example.restaurantescali.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.restaurantescali.viewmodel.Restaurante

@Composable
fun RestauranteDetalleScreen(
    restaurante: Restaurante,
    backgroundColor: Color,
    textColor: Color,
    surfaceColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(restaurante.imagenRes),
            contentDescription = restaurante.nombre,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = restaurante.nombre,
            style = MaterialTheme.typography.headlineMedium,
            color = textColor
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = restaurante.descripcion,
            style = MaterialTheme.typography.bodyLarge,
            color = textColor
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Dirección: ${restaurante.direccion}",
            style = MaterialTheme.typography.bodyMedium,
            color = textColor.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = "Valoración",
                tint = Color(0xFFFFC107),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${restaurante.valoracion} (${restaurante.numeroResenas} reseñas)",
                color = textColor,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
