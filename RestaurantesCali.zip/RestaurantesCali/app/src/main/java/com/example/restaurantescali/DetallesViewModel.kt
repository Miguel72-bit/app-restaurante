package com.example.restaurantescali.viewmodel

import androidx.annotation.DrawableRes
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.restaurantescali.R

data class Restaurante(
    val nombre: String,
    val descripcion: String,
    val direccion: String,
    @DrawableRes val imagenRes: Int,
    val valoracion: Float,
    val numeroResenas: Int
)

class DetallesViewModel : ViewModel() {

    private val _restauranteData = MutableLiveData<Restaurante>().apply {
        value = Restaurante(
            nombre = "Storia D’Amore",
            descripcion = "Restaurante italiano elegante con platos clásicos.",
            direccion = "Calle 4 #10-30, Cali",
            imagenRes = R.drawable.storia,
            valoracion = 4.8f,
            numeroResenas = 135
        )
    }

    val restauranteData: LiveData<Restaurante> = _restauranteData
}
